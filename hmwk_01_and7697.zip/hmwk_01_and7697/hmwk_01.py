# Duong, Andrew
# and7697
# 2019-06-04
#--------------------------------------------------
def main() :
  print("Hello, world!")
  # Put an output statement here that prints "Hello, world!"

#--------------------------------------------------
if ( __name__ == '__main__' ) :
  main()

#--------------------------------------------------
