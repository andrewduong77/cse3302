// Duong, Andrew
// and7697
// 2019-06-04

using System;

public class hmwk_01
{
  static public void Main( string[] args )
  {
    Console.WriteLine("Hello, world!");
  }
}
