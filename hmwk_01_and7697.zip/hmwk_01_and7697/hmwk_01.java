// Duong, Andrew
// and7697
// 2019-06-04

public class hmwk_01 {
  public static void main( String[] args )
  {
    System.out.println("Hello, world!");
  }
}
