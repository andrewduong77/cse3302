// Dalio, Brian A.
// dalioba
// 2019-06-03

using System;

public class hmwk_01
{
  static public void Main( string[] args )
  {
    // Put an output statement here that prints "Hello, world!"
  }
}
