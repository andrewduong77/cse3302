// Dalio, Brian A.
// dalioba
// 2019-06-03

public class hmwk_01 {
  public static void main( String[] args )
  {
    // Put an output statement here that prints "Hello, world!"
  }
}
