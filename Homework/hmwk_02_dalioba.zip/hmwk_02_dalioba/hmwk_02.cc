// Dalio, Brian A.
// dalioba
// 2019-06-05

#include <iostream>

using namespace std;

int main( int argc, char *argv[] )
{
  // Put an output statement here that prints "Hello, world!"
}
