// Duong, Andrew
// and7697
// 2019-06-06

#include <stdio.h>

int main( int argc, char *argv[] )
{
  printf("Hello, world!\n");
}
