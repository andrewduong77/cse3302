// Duong, Andrew
// and7697
// 2019-06-06

#include <iostream>

using namespace std;

int main( int argc, char *argv[] )
{
  cout << "Hello, world!" << endl;
}
