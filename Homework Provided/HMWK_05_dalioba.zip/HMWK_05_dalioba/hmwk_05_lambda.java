// Dalio, Brian A.
// dalioba
// 2019-06-26

import java.util.function.UnaryOperator;
import java.util.function.BinaryOperator;

public class hmwk_05_lambda {
  //----------------------------------------------------------
  // sumOfCubes lambda goes here.

  // pseudoPell lambda goes here.

  // GCD lambda goes here.

  //----------------------------------------------------------
  public static void main( String[] args )
  {
    // Put for loop here that applies the sumOfCubes lambda.

    // Put for loop here that applies the pseudoPell lambda.

    // Put for loop here that applies the GCD lambda.
  }
}
